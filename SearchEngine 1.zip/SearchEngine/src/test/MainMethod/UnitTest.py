import logging
import unittest
from src.test.Log.Log import Log
from src.main.FindDrives.Drives import Drives
from src.main.Searching.ThreadCreating import CreateThreadAndSearch
from src.main.CustomExceptions.InvalidRootException import InvalidRootException


# logger instance
logger = Log()
logger.LogCall()
logger = logging.getLogger('Log.UnitTest')


class TestSearchEngine(unittest.TestCase):
    def setUp(self):
        logger.info("setUp function started")
        self.drive_obj = Drives()
        self.search_obj = CreateThreadAndSearch()

    def test_drive(self):
        logger.info("testing number of drives available")
        drives = self.drive_obj.get_drives()
        length = len(drives)
        self.assertEqual(length, 3)

    def test_search(self):
        logger.info("testing search feature")
        self.search_obj.search_all_drives('D:', 'asdfghjkl.txt', 4)
        number_of_matches = self.search_obj.matches
        self.assertEqual(number_of_matches, 1)

    # def test_exception(self):
    #     try:
    #         self.search_obj.search_all_drives('D:', 'qwertyuiop.txt', 7)
    #     except InvalidRootException as i:
    #         self.assertEqual(type(i), InvalidRootException)

