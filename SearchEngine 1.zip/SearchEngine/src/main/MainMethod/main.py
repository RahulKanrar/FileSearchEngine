import logging
from src.main.Log.Log import Log
from src.main.Database.Suggestion import Suggestions
from src.main.MainMethod.mainOperations import MainOperations


# logger instance
logger = Log()
logger.LogCall()
logger = logging.getLogger('Log.Main')


def main():

    logger.info("inside main function")

    # Display starting screen
    logger.info("creating object of mainOperations class")
    operations = MainOperations()
    logger.info("mainOperations class object created")

    logger.info("calling menu method")
    operations.menu()
    logger.info("menu displayed")

    # Display suggestions if any
    logger.info("creating object of Suggestion class")
    suggestion = Suggestions()
    logger.info("Suggestion class object created")

    logger.info("calling suggestions")
    suggestion.suggest()
    logger.info("completed suggestions function")

    # Accept user input to process it
    logger.info("Collecting user input to process the request")
    result = operations.collect_user_input()
    logger.info("user input collected and processed")

    logger.info("result is returned to flask to be deployed as a service")
    return result


if __name__ == '__main__':

    main()
