import logging
from src.main.FindDrives.Drives import Drives
from src.main.Searching.ThreadCreating import CreateThreadAndSearch
from src.main.CustomExceptions.InvalidRootException import InvalidRootException


# logger instance
logger = logging.getLogger('Log.MainOperations')


class MainOperations:

    def __init__(self):

        logger.info("Constructor of MainOperation class initiated")
        self.results = []

    def menu(self):

        logger.info("menu function started")

        print("---------------------FILE SEARCH ENGINE APPLICATION---------------------")
        drive_obj = Drives()
        logger.info("Drives class object created")

        available_drives = drive_obj.get_drives()
        print(">> Available drives in this system are as follows:", available_drives)
        logger.info("available drives in the local system displayed")

    def collect_user_input(self):

        logger.info("collectUserInput function started")

        print(">> Enter the corresponding numbers from the given menu to proceed further:")
        drive_search_type = int(input("1. Search in 'C' drive\n2. Search in 'D' drive\n3. Search in 'E' drive "
                                      "\n4. Search in all drives\n"))
        logger.info("collected drive_search_type input from user")

        file_name = input(">> Enter File Name:")
        logger.info("collected file_name input from user")

        print(">> Enter the corresponding numbers from the given menu to proceed further:")
        type_of_search = int(input("1: StartsWith \n2: EndsWith \n3: Contains \n4: Exact\n"))
        logger.info("collected type_of_search input from user")

        self.results = self.process(file_name, drive_search_type, type_of_search)

        return self.results

    def process(self, file_name, drive_search_type, type_of_search):

        self.results.clear()

        logger.info("process function started")
        try:

            threadObj = CreateThreadAndSearch()
            logger.info("CreateThreadAndSearch class object created")

            if drive_search_type == 1:

                logger.info("drive_search_type is 1")
                self.results = threadObj.search_all_drives("C:\\", file_name, type_of_search)

            elif drive_search_type == 2:

                logger.info("drive_search_type is 2")
                self.results = threadObj.search_all_drives("D:\\", file_name, type_of_search)

            elif drive_search_type == 3:

                logger.info("drive_search_type is 3")
                self.results = threadObj.search_all_drives("E:\\", file_name, type_of_search)

            elif drive_search_type == 4:

                logger.info("drive_search_type is 4")
                self.results = threadObj.create_thread_for_each_drive(file_name, type_of_search)

            else:

                logger.error("Invalid root is selected")
                raise InvalidRootException('Invalid root is selected')

        except InvalidRootException:

            logger.info("InvalidRootException was caught")
            print(">> Invalid Root/Search Type has been entered for search \n>> Please enter a valid entry from "
                  "the displayed menu next time")

        return self.results
