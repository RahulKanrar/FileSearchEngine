import logging
import win32api


# logger instance
module_logger = logging.getLogger('Log.Drives')


class Drives:

    def __init__(self):

        module_logger.info("Drives class constructor initiated")
        self.drives = []

    def get_drives(self):

        module_logger.info("get_drives function started")

        module_logger.info("fetching the available drives in the local system")
        for drive in win32api.GetLogicalDriveStrings().split('\000')[:-1]:
            self.drives.append(drive)

        module_logger.info("all drives present in the system are detected")
        return self.drives
