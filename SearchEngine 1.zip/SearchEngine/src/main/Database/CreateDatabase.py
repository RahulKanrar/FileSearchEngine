import mysql.connector

my_db = mysql.connector.connect(
        host='localhost',
        user='root',
        password='18598@Jks',
        database='SearchEngine')



# mydbcon = mydb()
# mycursor = mydbcon.cursor()
#
# # mycursor.execute("CREATE TABLE IF NOT EXISTS search (file_name VARCHAR(50) , search_path VARCHAR(500))")
# sql = "INSERT INTO search (file_name, search_path) VALUES (%s, %s)"
# val = ("jk", "search path here")
# mycursor.execute(sql, val)
# mydbcon.commit()
#
# mycursor.execute("SHOW TABLES")
# for i in mycursor:
#     print(i)
