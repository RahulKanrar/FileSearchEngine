import logging
from src.main.Database.CreateDatabase import my_db


# logger instance
module_logger = logging.getLogger('Log.Suggestion')

# database instance
cursor = my_db.cursor()


class Suggestions:

    def suggest(self):

        module_logger.info("suggest function started")

        module_logger.info("finding search pattern")
        cursor.execute("SELECT file_name FROM search GROUP BY file_name HAVING COUNT(file_name) >3")

        module_logger.info("fetching suggestions based on search pattern")
        rows = cursor.fetchall()

        if len(rows) > 0:

            module_logger.info("displaying the suggestions found")
            print(">> Suggestions based on number of frequent searches are as follows:")

            for file in rows:
                for f in file:
                    print(">", f)

        else:

            module_logger.info("no suggestions found based on search pattern")
            pass
