import logging


# logger instance
module_logger = logging.getLogger('Log.Exception')


class Error(Exception):
    """Base class for exceptions in this module"""
    pass


class InvalidRootException(Error):

    def __init__(self, message):

        module_logger.info("InvalidRootException __init__ function is called")
        self.message = message
