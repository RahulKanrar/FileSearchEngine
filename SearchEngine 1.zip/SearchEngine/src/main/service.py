from flask import Flask
from src.main.MainMethod.main import main


app = Flask(__name__)


@app.route('/')
def home():

    result = ''
    m = main()

    for i in m:
        result += i
        result += "<br>"

    return result


if __name__ == '__main__':
    app.run(debug=True)
