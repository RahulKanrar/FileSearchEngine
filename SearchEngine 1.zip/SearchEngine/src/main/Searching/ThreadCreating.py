import os
import time
import logging
from threading import Thread
from src.main.FindDrives.Drives import Drives
from src.main.Database.CreateDatabase import my_db
from src.main.CustomExceptions.InvalidRootException import InvalidRootException


# logger instance
module_logger = logging.getLogger('Log.ThreadCreating')

# Mysql instance
mycursor = my_db.cursor()


class CreateThreadAndSearch:

    def __init__(self):

        module_logger.info("CreateThreadAndSearch class constructor initiated")
        self.matches = 0
        self.records = 0
        self.results = []

    # insert files found into database
    def insert_into_db(self, file_name, search_path):

        module_logger.info("insert_into_db function started")

        sql = "INSERT INTO search (file_name, search_path) VALUES (%s, %s)"
        val = [file_name, search_path]
        mycursor.execute(sql, val)

        my_db.commit()

        module_logger.info("record of the file found is inserted and committed into database")

    # create thread for each drive
    def create_thread_for_each_drive(self, file_name, type_of_search):

        module_logger.info("create_thread_for_each_drive function started")

        drive_obj = Drives()
        available_drives = drive_obj.get_drives()

        listOfThreads = []
        module_logger.info("creating number of threads equivalent to drives in the system")
        for each in range(len(available_drives)):
            process = Thread(target=self.search_all_drives, args=(available_drives[each], file_name, type_of_search,))
            process.start()
            listOfThreads.append(process)

        for t in listOfThreads:
            t.join()
        module_logger.info("execution of all threads completed")

        return self.results

    # Search in drives
    def search_all_drives(self, drive, file_name, type_of_search):

        module_logger.info("search_all_drives function started")

        module_logger.info("searching database to check if the file was searched previously")
        self.database_search(file_name)
        module_logger.info("search for the file in database completed")

        # Searching
        try:

            # clearing the result list
            self.results.clear()

            for root, dirs, files in os.walk(drive):
                for f in files:

                    # incrementing number of files searched
                    self.records += 1

                    # for StartsWith
                    if type_of_search == 1:
                        if f.lower().startswith(file_name.lower()):
                            self.print_append_insert(root, f)

                        else:
                            continue

                    # for EndsWith
                    elif type_of_search == 2:
                        if f.lower().endswith(file_name.lower()):
                            self.print_append_insert(root, f)

                        else:
                            continue

                    # for Contains
                    elif type_of_search == 3:
                        if file_name.lower() in f:
                            self.print_append_insert(root, f)

                        else:
                            continue

                    # exact search
                    elif type_of_search == 4:
                        if file_name.lower() == f.lower():
                            self.print_append_insert(root, f)

                        else:
                            continue

                    else:

                        module_logger.info("InvalidRootException will be raised")
                        raise InvalidRootException('Invalid search type is selected')

        except InvalidRootException:

            module_logger.error("InvalidRootException is caught")
            print(">> Invalid Root/Search Type has been entered for search \n>> Please enter a valid entry from "
                  "the displayed menu next time")
            module_logger.info("application terminated")
            # sys.exit(0)

        print(">> Search completed in {} drive "
              "\n>> There were {:,d} matches out of {:,d} records searched.".format(drive, self.matches, self.records))

        module_logger.info("search completed in {} drive. There were {:,d} matches out of {:,d} records"
                           " searched.".format(drive, self.matches, self.records))

        return self.results

    def database_search(self, file_name):

        module_logger.info("database_search function started")

        # Checking in database
        mycursor.execute("SELECT DISTINCT * FROM search")
        rows = mycursor.fetchall()

        module_logger.info("searching for results in database")
        for every in rows:
            for each in every:
                if file_name in each:
                    print("Database result >> ", each)
        module_logger.info("search completed")

    def print_append_insert(self, root, f):

        module_logger.info("print_append_insert function started")

        print("Search result >> " + os.path.join(root, f))
        result = os.path.join(root, f).replace('\\', '/')
        self.results.append(result)
        module_logger.info("record appended to list")

        # incrementing number of matches found
        self.matches += 1

        # insert into db function call
        self.insert_into_db(f, os.path.join(root, f))
        time.sleep(1)
